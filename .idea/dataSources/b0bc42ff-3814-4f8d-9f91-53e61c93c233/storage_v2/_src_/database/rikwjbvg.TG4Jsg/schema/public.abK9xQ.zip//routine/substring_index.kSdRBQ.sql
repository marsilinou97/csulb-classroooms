create function substring_index(text, text, integer) returns text
    language sql
as
$$
SELECT array_to_string((string_to_array($1, $2)) [1:$3], $2);
$$;

alter function substring_index(text, text, integer) owner to cllwmanw;

